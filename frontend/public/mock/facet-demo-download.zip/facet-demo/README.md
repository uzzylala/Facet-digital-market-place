# Facet demo download

This file comes from the Facet UI boilerplate, which runs on mock data.
Once the app is connected to the real backend, buyers receive the seller's actual
product file through a short-lived, signed Neon Object Storage link.
